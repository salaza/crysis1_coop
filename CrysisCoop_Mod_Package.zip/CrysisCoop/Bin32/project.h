#pragma once

#define PROJECT_NAME "CrysisCoop"

#define PROJECT_VERSION "1.0.0.0"

#define PROJECT_VERSION_MAJOR 1
#define PROJECT_VERSION_MINOR 0
#define PROJECT_VERSION_PATCH 0
#define PROJECT_VERSION_TWEAK 0

#define PROJECT_DESCRIPTION "Crysis Singleplayer Co-op Mod with Full AI NPC Support"

#define PROJECT_HOMEPAGE_URL "https://github.com/ccomrade/c1-mod-sdk"
